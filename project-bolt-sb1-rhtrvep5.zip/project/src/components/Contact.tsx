import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Mail, Loader2, Send, CheckCircle2, Server, Laptop, Inbox } from 'lucide-react';

export const Contact: React.FC = () => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [showEmailAnimation, setShowEmailAnimation] = useState(false);
  const [userInfo, setUserInfo] = useState<Record<string, string>>({});

  useEffect(() => {
    const collectUserInfo = async () => {
      const info: Record<string, string> = {
        platform: navigator.platform,
        userAgent: navigator.userAgent,
        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
        localTime: new Date().toLocaleString(),
        referrer: document.referrer || 'Direct',
        pageUrl: window.location.href,
      };

      setUserInfo(info);
    };

    collectUserInfo();
  }, []);

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    setIsSubmitting(true);
    setShowEmailAnimation(true);
    
    setTimeout(() => {
      setSubmitted(true);
      setIsSubmitting(false);
      setTimeout(() => setShowEmailAnimation(false), 4000);
    }, 4000);
  };

  return (
    <div className="min-h-screen py-20 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
      <AnimatePresence>
        {showEmailAnimation && (
          <motion.div 
            className="fixed inset-0 bg-black/90 backdrop-blur-sm z-50 flex items-center justify-center"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <div className="relative w-full max-w-2xl h-64 flex items-center justify-between px-12">
              {/* Source (Laptop) */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex flex-col items-center"
              >
                <Laptop className="w-12 h-12 text-blue-400" />
                <span className="text-white/60 text-sm mt-2">Client</span>
              </motion.div>

              {/* Server */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1, transition: { delay: 1 } }}
                className="flex flex-col items-center"
              >
                <Server className="w-12 h-12 text-purple-400" />
                <span className="text-white/60 text-sm mt-2">Serveur</span>
              </motion.div>

              {/* Destination (Inbox) */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1, transition: { delay: 2 } }}
                className="flex flex-col items-center"
              >
                <Inbox className="w-12 h-12 text-green-400" />
                <span className="text-white/60 text-sm mt-2">Boîte mail</span>
              </motion.div>

              {/* Animated Email */}
              <motion.div
                className="absolute left-12 top-1/2 -translate-y-1/2"
                initial={{ x: 0, scale: 1 }}
                animate={[
                  { x: 0, scale: 1, rotate: 0 },
                  { x: "33%", scale: 0.8, rotate: 360, transition: { duration: 1 } },
                  { x: "66%", scale: 0.8, rotate: 720, transition: { duration: 1, delay: 1 } },
                  { x: "calc(100% - 48px)", scale: 1, rotate: 1080, transition: { duration: 1, delay: 2 } }
                ]}
              >
                <div className="relative">
                  <motion.div
                    className="absolute -inset-4 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full opacity-30 blur-lg"
                    animate={{
                      scale: [1, 1.2, 1],
                      opacity: [0.3, 0.5, 0.3]
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                      ease: "easeInOut"
                    }}
                  />
                  <Mail className="w-8 h-8 text-white relative z-10" />
                </div>
              </motion.div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-16"
        >
          <h1 className="text-4xl font-bold text-white mb-4">Me Contacter</h1>
          <div className="h-1 w-20 bg-gradient-to-r from-blue-500 to-purple-500 mx-auto rounded-full mb-8" />
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white/5 backdrop-blur-sm rounded-2xl p-8 border border-white/10"
        >
          <form 
            action="https://formsubmit.co/zeioux@protonmail.com" 
            method="POST" 
            onSubmit={handleSubmit}
            className="space-y-6"
          >
            <input type="hidden" name="_captcha" value="false" />
            
            {Object.entries(userInfo).map(([key, value]) => (
              <input 
                key={key}
                type="hidden"
                name={`user_info_${key}`}
                value={value}
              />
            ))}
            
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-white/60 mb-2">
                Nom
              </label>
              <input
                type="text"
                name="name"
                id="name"
                required
                className="w-full px-4 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300"
              />
            </div>

            <div>
              <label htmlFor="email" className="block text-sm font-medium text-white/60 mb-2">
                Email
              </label>
              <input
                type="email"
                name="email"
                id="email"
                required
                className="w-full px-4 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300"
              />
            </div>

            <div>
              <label htmlFor="message" className="block text-sm font-medium text-white/60 mb-2">
                Message
              </label>
              <textarea
                name="message"
                id="message"
                rows={6}
                required
                className="w-full px-4 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300"
              />
            </div>

            <motion.button
              type="submit"
              disabled={isSubmitting}
              className="group w-full px-6 py-3 bg-gradient-to-r from-blue-500 to-purple-500 text-white font-medium rounded-lg shadow-lg shadow-blue-500/25 hover:shadow-blue-500/40 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <span className="flex items-center">
                {isSubmitting ? (
                  <>
                    <Loader2 className="animate-spin h-5 w-5 mr-2" />
                    Envoi en cours...
                  </>
                ) : submitted ? (
                  <>
                    <CheckCircle2 className="h-5 w-5 mr-2" />
                    Message envoyé !
                  </>
                ) : (
                  <>
                    <Send className="h-5 w-5 mr-2 group-hover:translate-x-1 transition-transform" />
                    Envoyer
                  </>
                )}
              </span>
            </motion.button>
          </form>
        </motion.div>
      </div>
    </div>
  );
};