import React, { useState, useEffect, useRef } from 'react';
import { motion, useMotionValue, useSpring, useTransform } from 'framer-motion';
import { 
  Shield, 
  Network, 
  Cloud, 
  Download, 
  Mail, 
  Coffee, 
  Terminal, 
  MonitorCheck, 
  FileCode,
  Globe,
  Router,
  SwitchCamera,
  Network as NetworkIcon,
  ShieldCheck,
  Lock,
  HardDrive,
  Cpu,
  Server
} from 'lucide-react';
import { EasterEgg } from './EasterEgg';

interface HomeProps {
  onContactClick: () => void;
  onProjectsClick: () => void;
}

export const Home: React.FC<HomeProps> = ({ onContactClick, onProjectsClick }) => {
  const [coffeeCount, setCoffeeCount] = useState(0);
  const [showEasterEgg, setShowEasterEgg] = useState(false);

  // Mouse movement animation
  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);
  const smoothX = useSpring(mouseX, { damping: 50, stiffness: 400 });
  const smoothY = useSpring(mouseY, { damping: 50, stiffness: 400 });

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      const rect = document.body.getBoundingClientRect();
      mouseX.set(e.clientX - rect.left);
      mouseY.set(e.clientY - rect.top);
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, [mouseX, mouseY]);

  const personalInfo = {
    firstName: "Clément",
    lastName: "Martins--Baumann",
    title: "Étudiant en BTS SIO SISR",
    level: "2ème année",
    location: "Paris, France",
    experience: "En formation",
    availability: "Recherche alternance en administration systèmes et réseaux"
  };

  const skills = [
    {
      category: "Infrastructure",
      items: [
        { name: "Administration Linux", icon: Terminal },
        { name: "Windows Server", icon: MonitorCheck },
        { name: "Virtualisation", icon: Cloud },
        { name: "Active Directory", icon: FileCode },
        { name: "Supervision", icon: Cpu },
        { name: "Scripting", icon: Terminal }
      ],
      icon: Server,
      gradient: "from-cyan-500 to-blue-500"
    },
    {
      category: "Réseaux",
      items: [
        { name: "TCP/IP", icon: Globe },
        { name: "Routage", icon: Router },
        { name: "Switching", icon: SwitchCamera },
        { name: "VLANs", icon: NetworkIcon },
        { name: "Pare-feu", icon: Shield },
        { name: "VPN", icon: Lock }
      ],
      icon: Network,
      gradient: "from-indigo-500 to-purple-500"
    },
    {
      category: "Sécurité",
      items: [
        { name: "Sécurité réseau", icon: ShieldCheck },
        { name: "Cryptographie", icon: Lock },
        { name: "Authentification", icon: Lock },
        { name: "Sauvegarde", icon: HardDrive },
        { name: "Monitoring", icon: MonitorCheck },
        { name: "Hardening", icon: Shield }
      ],
      icon: Shield,
      gradient: "from-emerald-500 to-teal-500"
    }
  ];

  const handleCoffeeClick = () => {
    setCoffeeCount(prev => {
      if (prev === 9) {
        setShowEasterEgg(true);
      }
      return prev + 1;
    });
  };

  if (showEasterEgg) {
    return <EasterEgg onBack={() => setShowEasterEgg(false)} coffeeCount={coffeeCount} />;
  }

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Cursor */}
      <motion.div
        className="fixed pointer-events-none w-[500px] h-[500px] rounded-full bg-gradient-to-r from-blue-500/20 via-purple-500/20 to-pink-500/20 blur-3xl"
        style={{
          x: smoothX,
          y: smoothY,
          translateX: '-50%',
          translateY: '-50%'
        }}
      />

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center py-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative z-10 text-center space-y-12 max-w-4xl mx-auto px-4"
        >
          <motion.h1
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="text-7xl md:text-8xl font-bold"
          >
            <span className="bg-gradient-to-r from-[#60A5FA] via-[#93C5FD] to-[#3B82F6] text-transparent bg-clip-text">
              {personalInfo.firstName}
            </span>
            <br />
            <span className="bg-gradient-to-r from-[#A78BFA] via-[#C4B5FD] to-[#8B5CF6] text-transparent bg-clip-text opacity-90">
              {personalInfo.lastName}
            </span>
          </motion.h1>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
            className="space-y-6"
          >
            <h2 className="text-3xl md:text-4xl text-white/90 font-light tracking-wide">
              {personalInfo.title}
            </h2>
            <p className="text-xl text-white/70">
              {personalInfo.level} · {personalInfo.location}
            </p>
            <motion.div
              whileHover={{ scale: 1.05 }}
              className="inline-block px-6 py-3 bg-gradient-to-r from-cyan-500/10 to-blue-500/10 backdrop-blur-sm rounded-xl border border-white/10"
            >
              <p className="text-cyan-400 font-medium">
                {personalInfo.availability}
              </p>
            </motion.div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.6 }}
            className="flex flex-col sm:flex-row justify-center items-center gap-6"
          >
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={onContactClick}
              className="group relative w-full sm:w-auto px-8 py-4 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-xl text-white font-medium shadow-lg shadow-cyan-500/25 hover:shadow-cyan-500/40 transition-all duration-300"
            >
              <span className="flex items-center justify-center group-hover:translate-x-1 transition-transform duration-300">
                <Mail className="h-5 w-5 mr-2" />
                Me contacter
              </span>
            </motion.button>

            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="group relative w-full sm:w-auto px-8 py-4 bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 hover:border-white/20 transition-all duration-300"
            >
              <span className="flex items-center justify-center text-white group-hover:translate-x-1 transition-transform duration-300">
                <Download className="h-5 w-5 mr-2" />
                Télécharger CV
              </span>
            </motion.button>

            <motion.button
              whileHover={{ scale: 1.1, rotate: 10 }}
              whileTap={{ scale: 0.9 }}
              onClick={handleCoffeeClick}
              className="relative hidden sm:flex items-center justify-center w-12 h-12 rounded-full bg-gradient-to-r from-amber-500/10 to-amber-600/20 border border-white/10 hover:border-white/20"
              title="Un petit café ?"
            >
              <Coffee className="h-6 w-6 text-amber-400" />
              {coffeeCount > 0 && (
                <div className="absolute -top-2 -right-2 bg-amber-500 text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">
                  {coffeeCount}
                </div>
              )}
            </motion.button>
          </motion.div>
        </motion.div>
      </section>

      {/* Skills Section */}
      <section className="relative py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {skills.map((category, index) => (
              <motion.div
                key={category.category}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="bg-white/5 backdrop-blur-sm rounded-xl p-8 border border-white/10 hover:border-white/20 transition-all duration-300"
              >
                <div className="flex items-center gap-6 mb-8">
                  <motion.div
                    whileHover={{ scale: 1.1, rotate: 5 }}
                    className={`p-4 rounded-xl bg-gradient-to-br ${category.gradient} bg-opacity-10`}
                  >
                    {React.createElement(category.icon, {
                      className: "h-12 w-12 text-white"
                    })}
                  </motion.div>
                  <h3 className="text-xl font-semibold text-white">
                    {category.category}
                  </h3>
                </div>
                <div className="space-y-4">
                  {category.items.map((skill, skillIndex) => (
                    <motion.div
                      key={skillIndex}
                      initial={{ opacity: 0, x: -20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: index * 0.1 + skillIndex * 0.1 }}
                      className="flex items-center gap-3"
                    >
                      {React.createElement(skill.icon, {
                        className: "h-5 w-5 text-white/60"
                      })}
                      <span className="text-white/80">{skill.name}</span>
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;